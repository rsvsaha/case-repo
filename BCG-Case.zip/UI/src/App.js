import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import { PolicyTable } from './screens/policy-table';
import { GraphPage } from './screens/graph-page';
import { PolicyEdit } from './screens/policy-edit';
import axios from 'axios';
import { API_BASE_URL } from './constants';


function App() {
  
  axios.interceptors.request.use((request)=>{
    request.baseURL=API_BASE_URL;
    return request;
  },(error)=>{
      return Promise.reject(error);
  });
  
  
  return (
                
    <Router>
      <Switch>
        <Route path="/policy-table" component={PolicyTable}></Route>
        <Route path="/graph" component={GraphPage}></Route>
        <Route path="/policy-edit/:policy_id" component={PolicyEdit}></Route>
        <Redirect from="/" to="/policy-table"></Redirect>
      </Switch>
    </Router>
    
  );
}

export default App;
