import { FILTER_SALES_MONTH, SET_SALES_RESULT } from "./action-types";

const initialState = {
    monthlyGraphData:[],
    originalData:[]
}

export const graphPageReducer = (state=initialState,action) => {

    switch(action.type) {
        case SET_SALES_RESULT:
            return {...state,monthlyGraphData:action.payload,originalData:action.payload};
        case FILTER_SALES_MONTH:
            let filteredData = state.originalData.filter((val,idx)=>{
                return !action.payload.includes(val.month);
            });
            return {...state,monthlyGraphData:filteredData};
        default:
            return {...state};
    }
}