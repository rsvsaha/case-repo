import axios from "axios"
import { SET_SALES_RESULT,FILTER_SALES_MONTH } from "./action-types";

export const fetchGraphData = () => dispatch => {

    axios.get("/plot/get-sale-count-by-month/1/12")
    .then((result)=>{
        dispatch(setAllGraphData(result.data));
    })
    .catch((error)=>{
        console.log(error);
    });

}


export const setAllGraphData = (data) => {
    return {type:SET_SALES_RESULT,payload:data};
}

export const filterGraphData = (data) => {
    return {type:FILTER_SALES_MONTH,payload:data};
}