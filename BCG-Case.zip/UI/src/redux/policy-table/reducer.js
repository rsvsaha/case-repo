import { SET_SEARCH_RESULT } from "./action-types"

const initialState = {
    search_result:[],
    current_page:1,
    total_pages:1
}

export const policyTableReducer = (state=initialState,action) =>{

    switch(action.type){
        case SET_SEARCH_RESULT:
            return {...state,search_result:action.payload.policies,current_page:action.payload.current_page,
                total_pages:action.payload.total_pages};
        default:
            return {...state};

    }

}