import { SET_SEARCH_RESULT } from "./action-types";
import axios from 'axios';
export const searchAllResult = (page=1) => dispatch => {
    axios.get(`/policy/get-all-policies/${page}`)
    .then((result)=>{
        dispatch(setResults(result.data));
    })
    .catch((error)=>{
            console.log(error);
    })

}


export const searchFilteredResult = (search_by,search_item,page=1) => dispatch => {
    axios.get(`/policy/search-policies/${page}?search_by=${search_by}&search_id=${search_item}`)
        .then((result)=>{
            dispatch(setResults(result.data));
        }).catch((err)=>{
            console.log(err);
    });
}

export const setResults = (data) => {
    return {type:SET_SEARCH_RESULT,payload:data};
} 


