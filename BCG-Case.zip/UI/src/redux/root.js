import { combineReducers } from "redux";
import { graphPageReducer } from "./graph-page/reducer";
import {policyTableReducer} from './policy-table/reducer';

export const app = combineReducers({
    policyTable:policyTableReducer,
    graph:graphPageReducer});