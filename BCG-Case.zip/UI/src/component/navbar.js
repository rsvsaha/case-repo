import React from 'react';
import { Link } from 'react-router-dom';
import styles from './navbar.module.css';

export const NavBar = (props) =>{


    const isPolicySelected = () =>{
        if(props.history.location.pathname.includes("policy")){
            return true;
        }
        return false;
    }


    return(<div style={{position:"fixed",left:"0",top:"0",width:"10vh",backgroundColor:"black",display:"flex",flexDirection:"column",justifyContent:"flex-start",
    alignItems:"center",height:"100vh"}}>

            <div style={(isPolicySelected())?{backgroundColor:"#fffff"}:{backgroundColor:"#a0a0a0"}}  className={styles.icon_container}>
                <Link to="/" className={styles.link_container}>
                    <img src="/briefcase-sharp.svg" alt="table" style={{width:"50%",height:"50%"}}></img>
                </Link>
            </div>
            <div style={(!isPolicySelected())?{backgroundColor:"#fffff"}:{backgroundColor:"#a0a0a0"}} className={styles.icon_container}>
                <Link to="/graph"  className={styles.link_container}>
                        <img src="/bar-chart-sharp.svg" alt="graph" style={{width:"50%",height:"50%"}}></img>
                </Link>
            </div>

    </div>)

}