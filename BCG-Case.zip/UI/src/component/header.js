import React from 'react';

export const Header = (props) => {


    return(<div style={{width:"100%",backgroundColor:"black",height:"50px",display:"flex",alignItems:"center",justifyContent:"center",color:"white",fontSize:"20px"}}>

            Insurance Portal
        
    </div>)

}