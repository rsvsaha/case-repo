import React, { useState,useEffect } from 'react';
import { Container, Row, Col, InputGroup,Form, Button, Table } from 'react-bootstrap';
import axios from 'axios';
import { Header } from '../component/header';
import { NavBar } from '../component/navbar';

const getPolicyDetails = (policyId) => {
    return axios.get(`/policy/get-policy-details/${policyId}`);
}

const savePolicyDetails = (policy_details) =>{
    return axios.put("/policy/update-policy",policy_details)
}

export const PolicyEdit = (props) => {

    const [policy_details,set_policy_details] = useState(null);
    const [validated, setValidated] = useState(true);

    useEffect(()=>{
        getPolicyDetails(props.match.params.policy_id)
        .then((result)=>{
            console.log(result.data[0]);
                set_policy_details(result.data[0]);
        })
        .catch((error)=>{
            console.log(error);
        })
    },[])
    
    
    const validationCheck = (val) =>{
        if(Number.parseFloat(val) > 1000000){
            setValidated(false);
        }else{
            setValidated(true);
        }
    }

    const handleChange = (id,val) => {
        if(id === "premium"){
            validationCheck(val);
        }

        set_policy_details((prevVal)=>{
            let newVal = {...prevVal}
            newVal[id] = val;
            return newVal;
        });
    }
    
    const handleSubmit = (event) => {
        event.preventDefault();
        savePolicyDetails(policy_details)
        .then((result)=>{
            props.history.goBack();

        })
        .catch((err)=>{console.log(err)});
    };

    return (
        <>
        <NavBar {...props}></NavBar>
        <Header></Header>
        <div style={{marginLeft:"10vh"}}>        
        <Container fluid>
            <Row>
                <h4>Edit Policy Details</h4>
            </Row>
            <Row>
                <Col xs={12}>
                {(policy_details === null)? null:

                <Form onSubmit={handleSubmit}>
                    
                    <Form.Group style={{padding:"4px"}} as={Row} controlId="policy_id">
                        <Form.Label column sm={2}>
                        PolicyID
                        </Form.Label>
                        <Col sm={10}>
                        <Form.Control value={policy_details.policy_id} disabled type="text" placeholder="Policy ID" />
                        </Col>
                    </Form.Group>
                    <Form.Group style={{padding:"4px"}} as={Row} controlId="customer_id">
                        <Form.Label column sm={2}>
                        Customer ID
                        </Form.Label>
                        <Col sm={10}>
                        <Form.Control value={policy_details.customer_id} onChange={(e)=>{handleChange(e.target.id,e.target.value);}} type="text" placeholder="Customer ID" />
                        </Col>
                    </Form.Group>
                    <Form.Group style={{padding:"4px"}} as={Row} controlId="premium">
                        <Form.Label column sm={2}>
                        Premium
                        </Form.Label>
                        <Col sm={10}>
                        <Form.Control type="number" value={policy_details.premium} onChange={(e)=>{handleChange(e.target.id,e.target.value);}} placeholder="0" />
                        {(validated)?null:<div>Please enter a number less than 1 Million</div>}
                        </Col>
                    </Form.Group>
                    <Form.Group style={{padding:"4px"}} as={Row} controlId="date_of_purchase">
                        <Form.Label column sm={2}>
                            Purchase Date
                        </Form.Label>
                        <Col sm={10}>
                        <Form.Control
                        disabled
                        type="text" value={policy_details.date_of_purchase} placeholder="Purchase Date" />
                        </Col>
                    </Form.Group>
                    <Form.Group  style={{padding:"4px"}} as={Row} controlId="binaryvals">
                        <Col>
                            <Form.Check defaultChecked={policy_details.bodily_injury_liability} onChange={(e)=>{
                                handleChange(e.target.id,e.target.checked);
                            }} id={"bodily_injury_liability"} label="Bodily Injury Liability" />
                        </Col>
                        <Col>
                            <Form.Check defaultChecked={policy_details.collision} onChange={(e)=>{
                                handleChange(e.target.id,e.target.checked);
                            }}  id={"collision"} label="Collision" />
                        </Col>
                        <Col>
                        <Form.Check defaultChecked={policy_details.comprehension} onChange={(e)=>{
                                handleChange(e.target.id,e.target.checked);
                            }} id={"comprehension"} label="Comprehension" />
                        </Col>
                        <Col>
                            <Form.Check defaultChecked={policy_details.personal_injury_protection} onChange={(e)=>{
                                handleChange(e.target.id,e.target.checked);
                            }} id={"personal_injury_protection"} label="Personal Injury Protection" />
                        </Col>
                        <Col>
                            <Form.Check defaultChecked={policy_details.property_damage_liability} onChange={(e)=>{
                                handleChange(e.target.id,e.target.checked);
                            }} id={"property_damage_liability"} label="Property Damage Liability" />
                        </Col>
                    </Form.Group>
                    <Button type="submit" disabled={!validated}>SUBMIT</Button>
                </Form>
                }
                </Col>
                    
            </Row>
        </Container>
        </div>
        </>
    );
}

