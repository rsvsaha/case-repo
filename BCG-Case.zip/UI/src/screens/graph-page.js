import React, { useState,useEffect,useRef } from 'react';
import { Container, Row, Col, InputGroup,Form, Button, Table } from 'react-bootstrap';
import { Header } from '../component/header';
import { NavBar } from '../component/navbar';
import { ResponsiveContainer,BarChart,CartesianGrid,XAxis,YAxis,Tooltip,Bar,Legend  } from 'recharts';
import { useDispatch, useSelector } from 'react-redux';
import { fetchGraphData, filterGraphData } from '../redux/graph-page/actions';

export const GraphPage = (props) => {

    const removedMonths = useRef([]);
    const originalData = useSelector((state)=>state.graph.originalData);
    const monthlyGraphData = useSelector((state)=>state.graph.monthlyGraphData);
    const dispatch = useDispatch();

    useEffect(()=>{
        dispatch(fetchGraphData());
    },[]);

    
    const handleChange = (month,selected) => {

        if(!selected){
            removedMonths.current.push(month)
        }else{
            removedMonths.current = removedMonths.current.filter((val,idx)=> val !== month);
        }
        dispatch(filterGraphData(removedMonths.current));
    }

    
    return(
    <>
    <NavBar {...props}></NavBar>
    <Header></Header>
    <div style={{marginLeft:"10vh"}}>        
        
        <Container fluid>
        <Row>
            <Col xs={12}>
            <Row>
                <h1>Insurance Sales Chart for Year 2018</h1>
            </Row>

            <Row>
                <Col>
                <ResponsiveContainer widht="100%" height={400}>
                    <BarChart data={monthlyGraphData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="sale" fill="#82ca9d" />
                    </BarChart>
                </ResponsiveContainer>
                </Col>
            </Row>
            <Row>
                <Col>Sale for the months</Col>
            </Row>
            <Form.Group as={Row} controlId="monthVals">
                {
                    originalData.map((val,idx)=>{
                        return(
                            <Col key={idx}>
                            <Form.Check defaultChecked={true}  onChange={(e)=>{
                                handleChange(e.target.id,e.target.checked);
                            }} id={val.month} label={val.month} />
                            </Col>
                        )
                    })
                }
       
            </Form.Group>
                
            </Col>
                
        </Row>
        </Container>
    </div>
    
    </>);
}