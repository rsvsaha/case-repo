import React, { useEffect, useState } from 'react';
import { Container, Row, Col, InputGroup,Form, FormControl, Button, Table, Pagination } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { NavBar } from '../component/navbar';
import { Header } from '../component/header';
import { useDispatch, useSelector } from 'react-redux';
import { searchAllResult,searchFilteredResult } from '../redux/policy-table/actions';
 
const CUSTOMER_SEARCH = "customer";
const POLICY_SEARCH = "policy";
const ALL_SEARCH = "all"

export const PolicyTable = (props) => {

    const [search_item, set_search_item] = useState("");
    const [search_by,set_search_by] = useState(ALL_SEARCH);
    const search_result = useSelector((state)=>state.policyTable.search_result);
    const current_page = useSelector((state)=>state.policyTable.current_page);
    const total_pages = useSelector((state)=>state.policyTable.total_pages);
    const dispatch = useDispatch();


    useEffect(()=>{
        dispatch(searchAllResult());
    },[]);


    return (
        <>
        <NavBar {...props}></NavBar>
        <Header></Header>
        <div style={{paddingTop:"10px",marginLeft:"10vh"}}>
        <Container fluid>
            <Row>
                <Col>
                    <Row>
                        <InputGroup size="lg">
                        <FormControl aria-label="Large" value={search_item} onChange={(e)=>{set_search_item(e.target.value)}} 
                        aria-describedby="inputGroup-sizing-sm" />
                        <Button variant="outline-secondary" onClick={(e)=>{
                            
                            if(search_by === ALL_SEARCH){
                                dispatch(searchAllResult());
                            }else{
                                dispatch(searchFilteredResult(search_by,search_item));
                            }
                            }}>Search</Button>
                        </InputGroup>
                    </Row>
                    <Row>
                    <Form>
                        <Row>
                        <Col>
                        <Form.Label column>
                            Search By
                        </Form.Label>
                        </Col>
                        <Col>
                            <Form.Check
                                inline
                                label="All"
                                name="group1"
                                type={`radio`}
                                id={`inline-radio-1`}
                                value={ALL_SEARCH}
                                checked={search_by === ALL_SEARCH}
                                onChange={(e)=>{
                                    set_search_item("");
                                    set_search_by(e.target.value);
                                    dispatch(searchAllResult());}}
                            />
                        </Col>
                        <Col>
                            <Form.Check
                                inline
                                label="Customer ID"
                                name="group1"
                                type={`radio`}
                                id={`inline-radio-2`}
                                value={CUSTOMER_SEARCH}
                                checked={search_by === CUSTOMER_SEARCH}
                                onChange={(e)=>{set_search_by(e.target.value);}}
                            />
                        </Col>
                        <Col>
                            <Form.Check
                                inline
                                label="Policy ID"
                                name="group1"
                                type={`radio`}
                                id={`inline-radio-3`}
                                value={POLICY_SEARCH}
                                checked={search_by === POLICY_SEARCH}
                                onChange={(e)=>{set_search_by(e.target.value);}}
                            />
                        </Col>
                        </Row>
                            
                        
                    </Form>

                    </Row>
                    <Row>
                    <Table responsive>
                    <thead>
                        <tr>
                            <th>Policy ID</th>
                            <th>Customer ID</th>
                            <th>Date of Purchase</th>
                            <th>Premium</th>
                            <th>Fuel Type</th>
                            <th>Vechicle Segment</th>
                        </tr>
                    </thead>
                    <tbody>
                        {search_result.map((val,idx)=>{
                            return(<tr key={idx}>
                                <td>
                                    <Link to={`/policy-edit/${val.policy_id}`}>
                                        {val.policy_id}
                                    </Link>
                                </td>
                                <td>{val.customer_id}</td>
                                <td>{val.date_of_purchase}</td>
                                <td>{val.premium}</td>
                                <td>{val.fuel_type.fuel_type}</td>
                                <td>{val.vehicle_segment_type.segment_type}</td>
                            </tr>);
                        })}
                        
                    </tbody>
                    </Table>
                    </Row>
                    <Row>
                        {(()=>{
                            let items = [];
                            for (let number = 1; number <= total_pages; number++) {
                              items.push(
                                <Pagination.Item onClick={(e)=>{
                                    if(search_by === ALL_SEARCH){
                                        dispatch(searchAllResult(number));
                                    }else{
                                        dispatch(searchFilteredResult(search_by,search_item,number));
                                    }
                                    if(window){
                                        window.scrollTo(0,0);
                                    }
                                }} key={number} active={number === current_page}>
                                  {number}
                                </Pagination.Item>,
                              );
                            }
                            return (<Pagination>{items}</Pagination>)
                        })()}
                    </Row>
                </Col>
            </Row>
        </Container>
        
        </div>
        </>
    )
}

