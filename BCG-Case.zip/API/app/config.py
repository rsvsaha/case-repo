data_base_url = "mysql://{user}:{pwd}@localhost/{dbname}".format(user="root",pwd="rishav",dbname="bcg_insurance_case")
port = 8000