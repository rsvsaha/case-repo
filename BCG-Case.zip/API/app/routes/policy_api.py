from flask import Blueprint,jsonify,request
from db.db_shared import db
from models.CustomerRegion import CustomerRegion
from models.Customer import Customer
from dto.CustomerRegionSchema import CustomerRegionSchema
from dto.CustomerSchema import CustomerSchema
from dto.PolicySchema import PolicySchema
from models.Policy import Policy

policy_route = Blueprint('policy',__name__)
customer_Schema = CustomerSchema(many=True)
policy_Schema = PolicySchema(many=True)

    
# For searching policies
@policy_route.route("/search-policies/<int:page>",methods=["GET"])
def search_policies(page=1):
    search_by = request.args.get('search_by')
    if(search_by == "customer"):
        id_to_search = request.args.get('search_id')
        policies = Policy.query.filter_by(customer_id=id_to_search).paginate(page,100,error_out=False)
        totalPages = policies.pages
        pageNumber = policies.page
        policies = policy_Schema.dump(policies.items)
        return jsonify({"total_pages":totalPages,"page_number": pageNumber,"policies":policies})
    elif(search_by == "policy"):
        id_to_search = request.args.get('search_id')
        policies = Policy.query.filter_by(policy_id=id_to_search).paginate(page,100,error_out=False)
        totalPages = policies.pages
        pageNumber = policies.page
        policies = policy_Schema.dump(policies.items)
        
        return jsonify({"total_pages":totalPages,"page_number": pageNumber,"policies":policies})
        
    return search_by

# For getting all policies
@policy_route.route("/get-all-policies/<int:page>",methods=["GET"])
def get_all_policies(page):
    policies = Policy.query.order_by(Policy.date_of_purchase.desc()).paginate(page,100,error_out=False)
    totalPages = policies.pages
    pageNumber = policies.page
    policies = policy_Schema.dump(policies.items)
    return jsonify({"total_pages":totalPages,"page_number": pageNumber,"policies":policies})



# For getting policy details
@policy_route.route("/get-policy-details/<int:policy_id>",methods=["GET"])
def get_policy_details(policy_id):
    policy = Policy.query.filter_by(policy_id=policy_id)
    print(type(policy))
    return policy_Schema.dumps(policy)


# For updating policies
@policy_route.route("/update-policy",methods=["PUT"])
def update_policy():
    newPolicySchema = PolicySchema()
    policyDetails = newPolicySchema.load(request.get_json())
    policyDetails = Policy.query.filter_by(policy_id=policyDetails['policy_id']).update(dict(customer_id=policyDetails['customer_id'],
    premium=policyDetails['premium'],comprehension=policyDetails['comprehension'],collision=policyDetails['collision'],
    bodily_injury_liability=policyDetails['bodily_injury_liability'],
    property_damage_liability=policyDetails['property_damage_liability'],
    personal_injury_protection=policyDetails['personal_injury_protection']))
    db.session.commit()
    return newPolicySchema.dump(policyDetails)
