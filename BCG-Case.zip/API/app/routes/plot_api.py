from flask import Blueprint,jsonify,request
from db.db_shared import db
from sqlalchemy import text
import calendar
plot_route = Blueprint('plot',__name__)

@plot_route.route("/get-sale-count-by-month/<int:start_month>/<int:end_month>",methods=["GET"])
def get_sale_count(start_month=1,end_month=12,year=2018):
    sql = text('SELECT COUNT(policy_id),MONTH(date_of_purchase) from policy WHERE YEAR(date_of_purchase) ={year} AND MONTH(date_of_purchase) >={start} AND MONTH(date_of_purchase)<={end} GROUP BY MONTH(date_of_purchase)'
    .format(start=start_month,end=end_month,year=year))
    result = db.engine.execute(sql)
    result = [{"month":calendar.month_name[row[1]],"sale":row[0]} for row in result]
    return jsonify(result)