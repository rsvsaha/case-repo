from flask import Flask
from flask_cors import CORS
from db.db_shared import db
from dto.dto_parser import ma
from routes.policy_api import policy_route
from routes.plot_api import plot_route
from models import Customer,CustomerGender,CustomerIncome,CustomerRegion,Fuel,Policy,VehicleSegment
from config import data_base_url,port

if __name__ == '__main__':
   app = Flask(__name__)
   app.register_blueprint(policy_route,url_prefix='/policy')
   app.register_blueprint(plot_route,url_prefix="/plot")
   app.config["SQLALCHEMY_DATABASE_URI"] = data_base_url
   CORS(app)
   app.config['CORS_HEADERS'] = 'Content-Type'
   db.init_app(app)
   ma.init_app(app)
   with app.app_context():
      db.create_all()
   app.run(debug = True,port=port,host="0.0.0.0")