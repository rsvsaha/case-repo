from models.CustomerRegion import CustomerRegion
from dto.dto_parser import ma
class CustomerRegionSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = CustomerRegion
        load_instance=True
    region_value = ma.auto_field()
