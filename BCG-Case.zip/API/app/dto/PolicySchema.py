from dto.dto_parser import ma
from models.Policy import Policy
from dto.FuelSchema import FuelSchema
from dto.VechicleSegmentSchema import VehicleSegmentSchema


class PolicySchema(ma.SQLAlchemySchema):
    class Meta:
        model = Policy

    policy_id = ma.auto_field()
    date_of_purchase = ma.auto_field()
    premium = ma.auto_field()
    bodily_injury_liability = ma.auto_field()
    personal_injury_protection = ma.auto_field()
    property_damage_liability = ma.auto_field()
    collision = ma.auto_field()
    comprehension = ma.auto_field()
    fuel_id= ma.auto_field()
    vehicle_segment_id = ma.auto_field()
    customer_id = ma.auto_field()
    fuel_type = ma.Nested(FuelSchema)
    vehicle_segment_type = ma.Nested(VehicleSegmentSchema)