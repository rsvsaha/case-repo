from models.CustomerIncome import CustomerIncome
from dto.dto_parser import ma
class CustomerIncomeSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = CustomerIncome
        load_instance=True
    income_range = ma.auto_field()