from dto.dto_parser import ma
from models.Customer import Customer
class CustomerSchema(ma.SQLAlchemySchema):
    class Meta:
        model = Customer

    customer_id = ma.auto_field()
    customer_gender = ma.auto_field()
    customer_income = ma.auto_field()
    customer_region = ma.auto_field()