from dto.dto_parser import ma
from models.Fuel import Fuel
class FuelSchema(ma.SQLAlchemySchema):
    class Meta:
        model = Fuel
    fuel_id= ma.auto_field()
    fuel_type = ma.auto_field()