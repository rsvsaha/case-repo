from dto.dto_parser import ma
from models.VehicleSegment import VehicleSegment
class VehicleSegmentSchema(ma.SQLAlchemySchema):
    class Meta:
        model = VehicleSegment
    segment_id = ma.auto_field()
    segment_type = ma.auto_field()