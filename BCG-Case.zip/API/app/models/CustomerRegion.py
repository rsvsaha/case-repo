from db.db_shared import db
class CustomerRegion(db.Model):
   # The unique constraint must be a tuple
   __table_args__=(db.UniqueConstraint('region_value',name='unique_customer_region_constraint'),)
   region_id = db.Column(db.Integer, primary_key = True)
   region_value = db.Column(db.String(20),nullable=False)
   