from db.db_shared import db
class CustomerGender(db.Model): 
   # Must be a tuple
   __table_args__= (db.UniqueConstraint('gender_value',name='unique_customer_gender_constraint'),)
   gender_id = db.Column(db.Integer, primary_key = True)
   gender_value = db.Column(db.String(20))
   
   
