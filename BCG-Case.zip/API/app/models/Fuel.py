from db.db_shared import db
class Fuel(db.Model):
   __table_args__ = (db.UniqueConstraint('fuel_type',name='unique_fuel_type_constraint'),)
   fuel_id = db.Column(db.Integer, primary_key = True)
   fuel_type = db.Column(db.String(10))
   