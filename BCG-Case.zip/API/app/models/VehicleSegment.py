from db.db_shared import db

class VehicleSegment(db.Model):
   __table_args__ = (db.UniqueConstraint('segment_type',name='unique_segment_type_constraint'),)
   segment_id = db.Column(db.Integer, primary_key = True)
   segment_type = db.Column(db.String(1))
   