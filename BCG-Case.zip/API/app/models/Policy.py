from db.db_shared import db
from models.Customer import Customer
from models.Fuel import Fuel
from models.VehicleSegment import VehicleSegment
class Policy(db.Model):
   policy_id = db.Column(db.Integer, primary_key = True)
   date_of_purchase = db.Column(db.Date)
   premium = db.Column(db.Float) 
   bodily_injury_liability = db.Column(db.Boolean)
   personal_injury_protection = db.Column(db.Boolean)
   property_damage_liability = db.Column(db.Boolean)
   collision = db.Column(db.Boolean)
   comprehension = db.Column(db.Boolean)
   fuel_id= db.Column(db.Integer,db.ForeignKey(Fuel.fuel_id))
   vehicle_segment_id = db.Column(db.Integer,db.ForeignKey(VehicleSegment.segment_id))
   customer_id = db.Column(db.Integer,db.ForeignKey(Customer.customer_id))
   fuel_type = db.relationship("Fuel")
   vehicle_segment_type = db.relationship("VehicleSegment")
