from db.db_shared import db
from models.CustomerGender import CustomerGender
from models.CustomerIncome import CustomerIncome
from models.CustomerRegion import CustomerRegion


class Customer(db.Model):
   customer_id = db.Column(db.Integer, primary_key = True)
   customer_gender = db.Column(db.Integer,db.ForeignKey(CustomerGender.gender_id))
   customer_income = db.Column(db.Integer,db.ForeignKey(CustomerIncome.cincome_id))
   customer_region = db.Column(db.Integer,db.ForeignKey(CustomerRegion.region_id))
   

