from db.db_shared import db

class CustomerIncome(db.Model):
   cincome_id = db.Column(db.Integer, primary_key = True)
   income_range = db.Column(db.String(10))